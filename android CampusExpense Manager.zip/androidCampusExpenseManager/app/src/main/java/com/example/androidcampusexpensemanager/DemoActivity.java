package com.example.androidcampusexpensemanager;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class DemoActivity  extends AppCompatActivity {
    private EditText nameTextEdit;
    //ButtonEnnerText
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid_layout_3);
        //initialize views (demolayout)
//        nameTextEdit= findViewById(R.id.nameTextEdit);

    }
    //ButtonClick event handle
    public void onSubmitButtonClick(View view){
        String name = nameTextEdit.getText().toString();
        String message = "Hello, "+ name + " !Chao May";
        Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
    }
}
