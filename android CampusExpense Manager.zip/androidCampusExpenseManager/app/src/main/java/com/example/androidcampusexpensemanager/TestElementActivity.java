package com.example.androidcampusexpensemanager;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class TestElementActivity extends AppCompatActivity {

    private CheckBox checkData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.actitvity_test_elements);
        super.onCreate(savedInstanceState);
        checkData = findViewById(R.id.cb_check);
        checkData.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Log.i("CheckingElement", "Checkbox is checked");
                } else {
                    Log.i("CheckingElement", "Checkbox is not checked");
                }
            }
        });

        findViewById(R.id.btn_check).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("    ", "Button is clicked");
            }
        });

        findViewById(R.id.rad_check).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("RadioButton", "RadioButton is clicked");
            }
        });
    }

    public void handleClickMe(View view) {
        Toast.makeText(this, "Click Me", Toast.LENGTH_SHORT).show();
        RadioButton rad = findViewById(R.id.rad_check);
        if (rad.isChecked()) {
            Toast.makeText(this, "RadioButton is clicked", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "RadioButton is not clicked", Toast.LENGTH_SHORT).show();
        }

        CheckBox cb = findViewById(R.id.cb_check);
        if (cb.isChecked()) {
            Toast.makeText(this, "CheckBox is clicked", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "CheckBox is not clicked", Toast.LENGTH_SHORT).show();
        }

        EditText text = findViewById(R.id.tv_text);
        String data = text.getText().toString().trim();
        Toast.makeText(this, data , Toast.LENGTH_SHORT).show();
    }
}
