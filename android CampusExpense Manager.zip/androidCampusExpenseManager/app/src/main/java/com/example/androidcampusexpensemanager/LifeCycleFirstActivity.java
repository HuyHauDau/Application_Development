package com.example.androidcampusexpensemanager;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class LifeCycleFirstActivity extends AppCompatActivity {
    public final String Tag = "LifeCycleFirstActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_life_cycle);
        findViewById(R.id.btn_start_activity).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), LifeCycleSecondActivity.class));
            }
        });
        Log.i(Tag, "++++++++++++++++++++++ onCreate +++++++++++++++++++++++++=");
    }

    @Override
    protected void onStart() {
        super.onStart();

        Log.i(Tag, "++++++++++++++++++++++ onStart +++++++++++++++++++++++++=");
    }

    @Override
    protected void onResume() {
        super.onResume();

        Log.i(Tag, "++++++++++++++++++++++ onResume +++++++++++++++++++++++++=");
    }

    @Override
    protected void onPause() {
        super.onPause();

        Log.i(Tag, "++++++++++++++++++++++ onPause +++++++++++++++++++++++++=");
    }

    @Override
    protected void onStop() {
        super.onStop();

        Log.i(Tag, "++++++++++++++++++++++ onStop +++++++++++++++++++++++++=");
    }

    @Override
    protected void onRestart() {
        super.onRestart();

        Log.i(Tag, "++++++++++++++++++++++ onRestart +++++++++++++++++++++++++=");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(Tag, "++++++++++++++++++++++ onDestroy +++++++++++++++++++++++++=");
    }
}
